//: Playground - noun: a place where people can play

import Foundation

/**
*
* Don't put too much into one protocol.
* Break it up into seperate protocols.
*/

class Document {

}

protocol Printer {
	func print(document: Document)
}

protocol Scanner {
	func scan(document: Document)
}

protocol Fax {
	func fax(document: Document)
}

protocol MultifunctionalMachine: Printer, Scanner, Fax {

}

class OrdinaryPrinter: Printer {
	func print(document: Document) {

	}
}

class PhotoCopier: Printer, Scanner {
	func print(document: Document) {

	}

	func scan(document: Document) {

	}
}

class MultiFunctionalDevice: MultifunctionalMachine {
	func print(document: Document) {

	}

	func scan(document: Document) {

	}

	func fax(document: Document) {

	}
}


