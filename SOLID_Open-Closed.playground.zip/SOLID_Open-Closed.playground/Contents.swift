//: Playground - noun: a place where people can play

import Foundation

enum Color {
	case black
	case white
	case blue
}

enum Size {
	case small
	case medium
	case large
}

class Product {
	var name: String!
	var color: Color!
	var size: Size!

	init(name: String, color: Color, size: Size) {
		self.name = name
		self.color = color
		self.size = size
	}
}

class ProductFilter {
	func filterByColor(products: [Product], color: Color) -> [Product] {
		return products.filter{ $0.color == color }
	}

	func filterBySize(products: [Product], size: Size) -> [Product] {
		return products.filter{ $0.size == size }
	}

	func filterBySizeAndColor(products: [Product], size: Size, color: Color) -> [Product] {
		return products.filter{ ($0.size == size) && ($0.color == color) }
	}
}

// Specification
protocol Specification {
	associatedtype T
	func isSatisfied(_ item: T) -> Bool
}

protocol Filter {
	associatedtype T
	func filter<Spec: Specification>(_ items: [T], _ spec: Spec) -> [T]
	where Spec.T == T;
}

class ColorSpecification: Specification {
	typealias T = Product
	let color: Color
	init(color: Color) {
		self.color = color
	}
	func isSatisfied(_ item: Product) -> Bool {
		return item.color == self.color
	}
}

class SizeSpecification: Specification {
	typealias T = Product
	let size: Size
	init(size: Size) {
		self.size = size
	}
	func isSatisfied(_ item: Product) -> Bool {
		return item.size == self.size
	}
}

class AndSpecification<T, SpecA: Specification, SpecB: Specification> : Specification
where SpecA.T == SpecB.T, T == SpecA.T, T == SpecB.T {
	let first: SpecA
	let second: SpecB
	init(first: SpecA, second: SpecB) {
		self.first = first
		self.second = second
	}
	func isSatisfied(_ item: T) -> Bool {
		return first.isSatisfied(item) && second.isSatisfied(item)
	}
}

class BetterFilter: Filter {
	typealias T = Product

	func filter<Spec>(_ items: [Product], _ spec: Spec) -> [Product] where Spec : Specification, BetterFilter.T == Spec.T {
		return items.filter{ spec.isSatisfied($0) }
	}
}

func main() {
	print("✡️ MAIN ✡️")
	let nightWear = Product(name: "Night Wear", color: Color.white, size: Size.medium)
	let beachWear = Product(name: "Beach Wear", color: Color.blue, size: Size.large)
	let dayWear = Product(name: "Day Wear", color: Color.black, size: Size.small)
	let products = [nightWear, beachWear, dayWear]
	let result1 = ProductFilter().filterByColor(products: products, color: .black)
	let result2 = ProductFilter().filterBySize(products: products, size: .large)
	let result3 = ProductFilter().filterBySizeAndColor(products: products, size: .medium, color: .white)
	print("Black colored product: \(result1[0].name)")
	print("Large size product:    \(result2[0].name)")
	print("White and Medium size product:    \(result3[0].name)")

	let bf = BetterFilter()
	let result4 = bf.filter(products, ColorSpecification(color: .blue))
	print("♨️ BetterFilter: \(result4[0].name)")
	let result5 = bf.filter(products, AndSpecification(first: ColorSpecification(color: .white), second: SizeSpecification(size: .medium)))
	print("♨️ BetterFilter: \(result5[0].name)")

}

main()
