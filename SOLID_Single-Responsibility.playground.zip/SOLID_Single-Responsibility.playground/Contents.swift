//: Playground - noun: a place where people can play

import Foundation

class Reminder: CustomStringConvertible {
	var tasks = [String]()
	var count = 0

	func addTask(newTask: String) -> Int {
		count = count + 1
		tasks.append("\(count): \(newTask)")
		return (count - 1)
	}

	func removeTask(index: Int) {
		tasks.remove(at: index)
	}

	var description: String {
		return tasks.joined(separator: "\n")
	}
}

// Separate out the responsibility of persistance
class Presistance {
	func saveToFile(reminder: Reminder, filename: String) {
		//
	}

	func loadFromFile(filename: String) {
		//
	}
}

func main() {
	let r = Reminder()
	let _ = r.addTask(newTask: "Bring milk")
	let _ = r.addTask(newTask: "Wash car")
	print(r)

	r.removeTask(index: 1)
	print("-------------")
	print(r)
}

main()
